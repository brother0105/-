<?php 

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('dbcon.php');


    $android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");


    if( (($_SERVER['REQUEST_METHOD'] == 'POST') && isset($_POST['submit'])) || $android )
    {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 가지고 값을 전달 받습니다.

        $recipe_num=$_POST['recipe_num'];
        $view_day=$_POST['view_day'];

        if(empty($recipe_num)){
            $errMSG = "id를 입력하세요.";
        }
        else if(empty($view_day)){
            $errMSG = "기한을 입력하세요.";
        }

        if(!isset($errMSG)) // 모두 입력이 되었다면 
        {
            try{
                // SQL문을 실행하여 데이터를 MySQL 서버의 page_view 테이블에 저장합니다. 
                $stmt = $con->prepare('UPDATE page_view SET view_day=:view_day WHERE recipe_num=:recipe_num');
                $stmt->bindParam(':recipe_num', $recipe_num);
                $stmt->bindParam(':view_day', $view_day);

                if($stmt->execute())
                {
                    $successMSG = "PV를 수정했습니다.";
                }
                else
                {
                    $errMSG = "PV 수정 에러";
                }

            } catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
            }
        }

    }

?>