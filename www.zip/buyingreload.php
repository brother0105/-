<?php 

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('dbcon.php');
        

    $stmt = $con->prepare('select tbi.recipe_num, category, i_name, quantity, recipe_name from tobuyingre AS tbi left outer join recipe AS rec on tbi.recipe_num = rec.recipe_num;');
    $stmt->execute();

    if ($stmt->rowCount() > 0)
    {
        $data = array(); 

        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
    
            array_push($data, 
                array(
				'number'=>$recipe_num,
                'recname'=>$recipe_name,
                'category'=>$category,
				'ingre'=>$i_name,
				'quantity'=>$quantity
            ));
        }

        header('Content-Type: application/json; charset=utf8');
        $json = json_encode(array("tester"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
        echo $json;
    }

?>