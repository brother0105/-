<?php 


	function customError($errno,$errstr)
	
	{
		echo "<b>Error:</b> [$errno] $errstr<br/>";
		var_dump($_POST);
	}

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('dbcon.php');


    $android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");

	set_error_handler("customError");

    if( (($_SERVER['REQUEST_METHOD'] == 'POST') && isset($_POST['submit'])) || $android )
    {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 가지고 값을 전달 받습니다.

        $recipe_num=(int)$_POST['recipe_num'];
        $category=$_POST['category'];
		$i_name=$_POST['i_name'];

        if(!isset($errMSG)) // 모두 입력이 되었다면 
        {
            try{
                // SQL문을 실행하여 데이터를 MySQL 서버의 tobuyingre 테이블에 저장합니다. 
                $stmt = $con->prepare('delete from tobuyingre where recipe_num=:recipe_num and category=:category and i_name=:i_name');
				$stmt->bindParam(':recipe_num',$recipe_num);
                $stmt->bindParam(':category', $category);
                $stmt->bindParam(':i_name', $i_name);

                if($stmt->execute())
                {
                    $successMSG = "사야할 재료를 추가했습니다.";
                }
                else
                {
                    $errMSG = "사야할 재료 추가 에러";
                }

            } catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
            }
        }

    }
	

?>