package com.example.recrecipe;


public class TestApiData {
    private String id = "";
    private String name = "";
    private String summery = "";
    private String type = "";
    private String cooking_time = "";
    private String calorie = "";
    private String level = "";
    private String url = "";


    public String get_id() {
        return id;
    }

    public String get_name() {
        return name;
    }

    public String get_summery() {
        return summery;
    }

    public String get_type() {
        return type;
    }

    public String get_cooking_time() {
        return cooking_time;
    }

    public String get_calorie() {
        return calorie;
    }

    public String get_level() {
        return level;
    }

    public String get_url() {
        return url;
    }

    public void set_id(String id) {
        this.id = id;
    }

    public void set_name(String name) {
        this.name = name;
    }

    public void set_summery(String summery) {
        this.summery = summery;
    }

    public void set_type(String type) {
        this.type = type;
    }

    public void set_cooking_time(String cooking_time) {
        this.cooking_time = cooking_time;
    }

    public void set_calorie(String calorie) {
        this.calorie = calorie;
    }

    public void set_level(String level) {
        this.level = level;
    }

    public void set_url(String url) {
        this.url = url;
    }
}
