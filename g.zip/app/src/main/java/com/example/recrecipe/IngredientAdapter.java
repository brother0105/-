package com.example.recrecipe;
//레시피 리스트의 커스텀 리스트뷰를 위한 클래스

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class IngredientAdapter extends BaseAdapter {
    private static String IP_ADDRESS = "10.0.2.2";
    // Adapter에 추가된 데이터를 저장하기 위한 ArrayList
    private ArrayList<RecipeIngredientListItem> listViewItemList = new ArrayList<RecipeIngredientListItem>() ;

    // IngredientAdapter의 생성자
    public IngredientAdapter() {

    }

    // Adapter에 사용되는 데이터의 개수를 리턴. : 필수 구현
    @Override
    public int getCount() {
        return listViewItemList.size() ;
    }

    // position에 위치한 데이터를 화면에 출력하는데 사용될 View를 리턴. : 필수 구현
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        // "listview_item" Layout을 inflate하여 convertView 참조 획득.
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.recipe_ingredient_design, parent, false);
        }

        // 화면에 표시될 View(Layout이 inflate된)으로부터 위젯에 대한 참조 획득
        TextView nameTextView = (TextView) convertView.findViewById(R.id.textView_list_ingredient) ;
        TextView volTextView = (TextView) convertView.findViewById(R.id.textView_list_ingredient_vol) ;
        //TextView memoTextView = (TextView) convertView.findViewById(R.id.textView_list_memo) ;

        Button ingreMemoBtn = (Button) convertView.findViewById(R.id.textView_list_memo_button);
        Button ingreInsertBtn = (Button) convertView.findViewById(R.id.textView_list_ingre_button);

        // Data Set(listViewItemList)에서 position에 위치한 데이터 참조 획득
        RecipeIngredientListItem listViewItem = listViewItemList.get(position);

        // 아이템 내 각 위젯에 데이터 반영
        nameTextView.setText(listViewItem.getName());
        volTextView.setText(listViewItem.getVol());
        //memoTextView.setText(listViewItem.getType());

        ingreInsertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipe_num;
                String category;
                String i_name;
                String quantity;

                recipe_num = listViewItem.getNum();
                category = listViewItem.getType();
                i_name = listViewItem.getName();
                quantity = listViewItem.getVol();

                InsertData task = new InsertData();
                task.execute("http://" + IP_ADDRESS + "/insertTobuyingre.php", recipe_num, category, i_name, quantity);
            }
        });

        return convertView;
    }

    // 지정한 위치(position)에 있는 데이터와 관계된 아이템(row)의 ID를 리턴. : 필수 구현
    @Override
    public long getItemId(int position) {
        return position ;
    }

    // 지정한 위치(position)에 있는 데이터 리턴 : 필수 구현
    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position) ;
    }

    // 아이템 데이터 추가를 위한 함수. 개발자가 원하는대로 작성 가능.
    public void addItem(String name, String vol, String recipe_num, String category) {
        RecipeIngredientListItem item = new RecipeIngredientListItem();

        item.setName(name);
        item.setVol(vol);
        item.setNum(recipe_num);
        item.setType(category);

        listViewItemList.add(item);
    }

    class InsertData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //progressDialog = ProgressDialog.show(ListViewAdapter.this,
            //"Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            //progressDialog.dismiss();
            //mTextViewResult.setText(result);
            //Log.d(TAG, "POST response  - " + result);
        }


        @Override
        protected String doInBackground(String... params) {

            String recipe_num = (String)params[1];
            String category = (String)params[2];
            String i_name = (String)params[3];
            String quantity = (String)params[4];
            String serverURL = (String)params[0];

            String postParameters = "recipe_num=" + recipe_num +
                    "&category=" + category + "&i_name=" + i_name + "&quantity=" + quantity;

            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                //Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString();


            } catch (Exception e) {

                //Log.d(TAG, "InsertData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }
}