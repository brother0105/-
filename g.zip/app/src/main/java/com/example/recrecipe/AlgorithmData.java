package com.example.recrecipe;

public class AlgorithmData {

    private String recipe_id;
    private String recipe_url;

    public String get_id() {
            return recipe_id;
        }
    public String get_url() {
            return recipe_url;
        }

    public void set_id(String id) {
            this.recipe_id = id;
        }
    public void set_url(String url) {
            this.recipe_url = url;
        }

}
