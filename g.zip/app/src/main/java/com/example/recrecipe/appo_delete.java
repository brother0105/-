package com.example.recrecipe;

public interface appo_delete{
    void on_Delete_Click (int value);
}