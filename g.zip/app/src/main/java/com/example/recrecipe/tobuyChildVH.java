package com.example.recrecipe;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class tobuyChildVH extends apporecipeitem {
    public TextView child_main;
    public TextView child_quantity;
    public Button child_button;
    int viewType=2;
    int recipe_num;

    public tobuyChildVH(View itemView) {
        super(itemView);
        child_main = (TextView) itemView.findViewById(R.id.child_main_text);
        child_quantity = (TextView) itemView.findViewById(R.id.child_quantity_text);
        child_button = (Button) itemView.findViewById(R.id.appo_child_button);
    }


    public void onBind(appo_recipe_adapter.itemlist data){
        child_main.setText(data.maincontext);
        child_quantity.setText(data.subcontext);
        recipe_num=data.list_num;
    }

    public void visibility(boolean a){//a=0 GONE, a=1 Visible
        if(a){
            child_main.setVisibility(View.VISIBLE);
            child_button.setVisibility(View.VISIBLE);
            child_quantity.setVisibility(View.VISIBLE);
        }
        else{
            child_main.setVisibility(View.GONE);
            child_button.setVisibility(View.GONE);
            child_quantity.setVisibility(View.GONE);
        }
    }
}
