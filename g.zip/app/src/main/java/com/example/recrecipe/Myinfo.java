package com.example.recrecipe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Myinfo extends customtoolbar {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myinfo);
    }
    public void onButtonIngreClicked(View v) {
        Intent intent = new Intent(getApplicationContext(), IngredientMenu.class);
        startActivity(intent);
    }
    public void EventGotomyview(View v){
        Intent intent = new Intent(getApplicationContext(), myview.class);
        startActivity(intent);
    }

}