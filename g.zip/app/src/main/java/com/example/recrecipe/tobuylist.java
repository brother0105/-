package com.example.recrecipe;
public class tobuylist{
    int recipe_num;//레시피 넘버, 구분용+혹시라도 모를 레시피에 직접 가는 용도
    String category;//카테고리. 구분용도
    String ingredient_name;//재료 이름
    String recipe_name;//레시피 이름
    String ingredient_quantity;//재료 양
}