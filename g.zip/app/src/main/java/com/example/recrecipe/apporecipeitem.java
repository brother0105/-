package com.example.recrecipe;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class apporecipeitem extends RecyclerView.ViewHolder {
    public apporecipeitem(@NonNull View view){
        super(view);
    }
    int viewtype=1;

    public int getViewtype() {
        return viewtype;
    }
}
