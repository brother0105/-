package com.example.recrecipe;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class appo_recipe_adapter extends RecyclerView.Adapter<apporecipeitem> {

    private appo_delete delete_call;

    private ArrayList<itemlist> listitem=null;

    boolean notorganize=true;//아직 정리가 안되었을때
    int organizevalue;//언제 정리하는지
    int headsize;
    tobuyHeadVH preinvisible;

    ArrayList<apporecipeitem> recycleitemlist;

    public appo_recipe_adapter(ArrayList<itemlist> list, appo_delete listener, int headsize) {
            this.listitem= list;
            delete_call=listener;
            organizevalue= listitem.size();
            this.headsize=headsize;
            recycleitemlist = new ArrayList<>();
            global_i=0;
            preinvisible=null;
    }

    @Override
    public int getItemViewType(int position){
        return position;
        //return listitem.get(position).getViewType();
    }

    int global_i;

    @Override
    public apporecipeitem onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        switch(this.listitem.get(global_i).getViewType()){
            case appo_type_code.ViewType.HEAD:
                LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.appo_list_header, parent, false);
                tobuyHeadVH header = new tobuyHeadVH(view);
                return header;

            case appo_type_code.ViewType.CHILD:
                LayoutInflater inflater2 = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater2.inflate(R.layout.appo_list_child,parent,false);
                tobuyChildVH child = new tobuyChildVH(view);
                return child;
        }


        return null;
    }

    public void onBindViewHolder(@NotNull apporecipeitem holder, int position) {
        holder.setIsRecyclable(false);
        if(holder instanceof tobuyHeadVH){
            tobuyHeadVH tobuyHeadVH = (tobuyHeadVH)holder;
            tobuyHeadVH.onBind(listitem.get(position));
            tobuyHeadVH.icon.setImageResource(R.drawable.downarrow);

            tobuyHeadVH.icon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tobuyHeadVH.visibility();
                }
            });
            recycleitemlist.add(tobuyHeadVH);

        }
        else if(holder instanceof  tobuyChildVH){
            tobuyChildVH tobuyChildVH = (tobuyChildVH) holder;
            tobuyChildVH.onBind(listitem.get(position));

            tobuyChildVH.child_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    delete_call.on_Delete_Click(tobuyChildVH.recipe_num);
                }
            });
            int size =recycleitemlist.size();
            ((tobuyHeadVH)recycleitemlist.get(size-1)).addchild(tobuyChildVH);
        }

        if(getItemCount()-1>global_i)
            global_i++;
/*
        if(organizevalue==global_i && notorganize)
            organization();
*/
    }

/*
    public void organization(){
        int i;
        for(i=0;i<headsize;i++){
            if(recycleitemlist.get(i) instanceof tobuyHeadVH){
                while(recycleitemlist.size()>i+1 && recycleitemlist.get(i+1) instanceof tobuyChildVH){
                    ((tobuyHeadVH) recycleitemlist.get(i)).addchild((tobuyChildVH) recycleitemlist.get(i+1));
                    recycleitemlist.remove(i+1);
                }
            }
            ((tobuyHeadVH) recycleitemlist.get(i)).icon.setImageResource(R.drawable.downarrow);
        }

    }
    */

    public void clear(){
        int size = recycleitemlist.size();
        if (size > 0) {
            for(int i =0; i<size; i++) {
                int sizechild=((tobuyHeadVH)recycleitemlist.get(0)).childlist.size();
                for(int i2=0; i2<sizechild; i2++){
                    ((tobuyHeadVH)recycleitemlist.get(0)).childlist.remove(0);
                }
            }
        }
    }


    public int getItemCount() {
        return listitem.size();
    }

    public static class itemlist {
        String maincontext;//head 이름, child 레시피 이름 or 재료 이름
        String subcontext;//child quantity
        int list_num;//apporecipe에서 childlist의 list번호
        int viewType;//viewtype 1이 head 2가 child
        public ArrayList<itemlist> children;

        public itemlist(String main, int type) {
            this.maincontext=main;
            this.viewType=type;
        }
        public itemlist(String main, String sub, int num, int type){
            this.maincontext=main;
            this.subcontext=sub;
            this.list_num=num;
            this.viewType=type;
        }

        public int getViewType(){
            return viewType;
        }
    }
}

