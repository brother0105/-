package com.example.recrecipe;
// 레시피 리스트의 커스텀 리스트뷰의 layout을 위한 클래스

public class SaveDescriptionAdapterItem {
    String id;
    int row;
    String description;
    String pic_name;

    public SaveDescriptionAdapterItem(){}
    public SaveDescriptionAdapterItem(String id, int row, String description, String pic_name){
        this.id = id;
        this.row = row;
        this.description = description;
        this.pic_name = pic_name;
    }

    public String get_id() {
        return id;
    }
    public int get_row(){
        return row;
    }
    public String get_description() {
        return description;
    };
    public String get_pic() {
        return pic_name;
    };


    public void set_id(String id) {
        this.id = id;
    }
    public void set_row(int row) {
        this.row = row;
    }
    public void set_description(String description) {
        this.description = description;
    }
    public void set_pic_name(String pic_name) {
        this.pic_name = pic_name;
    }
}



