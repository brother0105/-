package com.example.recrecipe;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class apporecipe extends customtoolbar implements appo_delete {//apporecipe 화면

    private String mJsonString;

    private ArrayList<String> headlist;//head쪽 string리스트, 분류
    private ArrayList<tobuylist> childlist;//child쪽 tobuylist 리스트

    private static String IP_ADDRESS = "10.0.2.2";
    private static String TAG = "phptest";

    private static final String TAG_JSON="tester";
    private static final String TAG_NUMBER = "number";//레시피 id
    private static final String TAG_RECNAME = "recname";//레시피 이름
    private static final String TAG_QUANTITY ="quantity";//수량
    private static final String TAG_INGRE="ingre";//재료 이름
    private static final String TAG_CATEGORY="category";//재료의 카테고리
    ArrayList<appo_recipe_adapter.itemlist> data;
    private apisaveclass apisaveclass=null;

    int viewnow;//중복클릭시 새로고침 방지용. 버튼클릭으로 새로고침시킬거면 삭제.

    EditText howmany;
    EditText whatingre;

    RecyclerView recyclerView;

    Button recipebutton;
    Button ingrebutton;
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.apporecipe);

        childlist = new ArrayList<tobuylist>();
        headlist=new ArrayList<String>();





        GetData baseinput = new GetData();
        baseinput.execute("http://"+IP_ADDRESS+"/buyingreload.php");



        recipebutton = (Button)findViewById(R.id.appo_sort_recipe);

        ingrebutton = (Button)findViewById(R.id.appo_sort_ingredient);

        recipebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewChange(0);
            }
        });

        ingrebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewChange(1);
            }
        });

        recyclerView = findViewById(R.id.apporeciperecyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        howmany=(EditText) findViewById(R.id.howmany);
        whatingre=(EditText) findViewById(R.id.whatingre);

        findViewById(R.id.input_tobuy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ingre=whatingre.getText().toString();
                String quantity=howmany.getText().toString();

                String check1=ingre.replaceAll(" ","");
                String check2=quantity.replaceAll(" ","");

                if(check1==""||check2==""){//둘 중 하나라도 공란이 있으면
                    Toast.makeText(getApplicationContext(), "공란이 있습니다, 입력해주세요.", Toast.LENGTH_LONG).show();
                }
                else{
                    inputbuyingre task = new inputbuyingre();
                    task.execute("http://"+IP_ADDRESS + "/buyingreinput.php",ingre,quantity);


                    //새로고침
                    Intent intent =getIntent();
                    finish();
                    overridePendingTransition(0,0);
                    startActivity(intent);
                    overridePendingTransition(0,0);


                }



            }
        });



    }



    private void ViewChange(int a){

        int i,i2;

        switch(a) {
            case 0:
                if(viewnow==0)
                    break;
                headlist.clear();
                data= new ArrayList<>();
                data.clear();


                for(i=0;i<childlist.size();i++){
                    if(!headlist.contains(childlist.get(i).recipe_name))
                        headlist.add(childlist.get(i).recipe_name);//이름으로 집어넣기. 이름이 같으면 어떻게? num으로 구분하게?
                }


                for(i=0;i<headlist.size();i++){
                    appo_recipe_adapter.itemlist newitem =new appo_recipe_adapter.itemlist(headlist.get(i),appo_type_code.ViewType.HEAD);//레시피 이름을 딴 head를 만들고
                    newitem.children = new ArrayList<>();
                    data.add(newitem);

                    for(i2=0;i2<childlist.size();i2++){
                        if(childlist.get(i2).recipe_name.equals(headlist.get(i))) {//head와 맞는 child들을 childlist에서 뽑아서 삽입
                            appo_recipe_adapter.itemlist childitem = new appo_recipe_adapter.itemlist(childlist.get(i2).ingredient_name, childlist.get(i2).ingredient_quantity, i2, appo_type_code.ViewType.CHILD);
                            //newitem.children.add(childitem);
                            data.add(childitem);
                        }
                    }
                }


                viewnow=0;
                break;

            case 1:
                if(viewnow==1)
                    break;
                headlist.clear();
                data= new ArrayList<>();


                for(i=0;i<childlist.size();i++){
                    if(!headlist.contains(childlist.get(i).ingredient_name))
                        headlist.add(childlist.get(i).ingredient_name);//재료이름으로 headlist에 넣기
                }

                for(i=0;i<headlist.size();i++){
                    appo_recipe_adapter.itemlist newitem =new appo_recipe_adapter.itemlist(headlist.get(i),appo_type_code.ViewType.HEAD);//재료 이름을 딴 head를 만들고
                    newitem.children = new ArrayList<>();


                    data.add(newitem);

                    for(i2=0;i2<childlist.size();i2++){
                        if(childlist.get(i2).ingredient_name.equals(headlist.get(i))) {//head와 맞는 child들을 childlist에서 뽑아서 삽입
                            appo_recipe_adapter.itemlist childitem = new appo_recipe_adapter.itemlist(childlist.get(i2).recipe_name, childlist.get(i2).ingredient_quantity, i2, appo_type_code.ViewType.CHILD);
                            //newitem.children.add(childitem);
                            data.add(childitem);
                        }
                    }
                }

                viewnow=1;
                break;

            default:
                break;
        }

        if(viewnow==0){//레시피순으로 보고 있을 때
            recipebutton.setBackgroundColor(Color.parseColor("#B7F0B1"));
            ingrebutton.setBackgroundColor(Color.parseColor("#0099cc"));
        }
        else{
            recipebutton.setBackgroundColor(Color.parseColor("#0099cc"));
            ingrebutton.setBackgroundColor(Color.parseColor("#B7F0B1"));
        }

        appo_recipe_adapter adapter = new appo_recipe_adapter(data,this,headlist.size());
        adapter.clear();
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    public void on_Delete_Click (int value){

        tobuylist del = childlist.get(value);

        String recipe_num=Integer.toString(del.recipe_num);

        deletebuyingre task = new deletebuyingre();
        task.execute("http://"+IP_ADDRESS+"/deletebuyingre.php",del.ingredient_name,del.category,recipe_num);

        //childlist.remove(value); 새로고침할거면 필요없음.
        
        //새로고침
        Intent intent =getIntent();
        finish();
        overridePendingTransition(0,0);
        startActivity(intent);
        overridePendingTransition(0,0);
    }





    private class GetData extends AsyncTask<String, Void, String> {//php통신
        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(apporecipe.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "response  - " + result);

            if (result == null){

            }
            else {

                mJsonString = result;
                inputData();//php로 받은 데이터를 childList에 넣는 작업
            }
        }

        @Override
        protected String doInBackground(String... params) {


            String serverURL = params[0];


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.connect();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString().trim();


            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }


    private void inputData(){//php로 받은 데이터를 childList에 넣는 작업
        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                tobuylist insert = new tobuylist();
                insert.recipe_num=item.getInt(TAG_NUMBER);
                insert.category=item.getString(TAG_CATEGORY);
                insert.ingredient_name=item.getString(TAG_INGRE);
                insert.ingredient_quantity=item.getString(TAG_QUANTITY);


                if(insert.recipe_num>195453) {//mysql에 있을때
                    insert.recipe_name = item.getString(TAG_RECNAME);
                }
                else if(insert.recipe_num==0){
                    insert.recipe_name = "개인입력";
                }
                else{//api일때
                    if(apisaveclass==null || Integer.parseInt(apisaveclass.recipe_num) != insert.recipe_num) {
                        String temp = "";
                        Task1 getnametask = new Task1();
                        try {
                            temp = getnametask.execute(Integer.toString(insert.recipe_num)).get();
                            insert.recipe_name = apirecipe(temp, Integer.toString(insert.recipe_num));

                        } catch (Exception e) {
                            String errorString = null;

                            Log.d(TAG, "InsertData: Error ", e);
                            errorString = e.toString();
                        }
                    }
                    else{
                        insert.recipe_name=apisaveclass.recipe_name;
                    }
                }

                childlist.add(insert);

            }
            viewnow=1;
            ViewChange(0);


        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }


    public class Task1 extends AsyncTask<String, Void, String> {

        String clientKey = "0fc288b3d2d49b8b523acee959792ea82e58b0079517e6b1940e06350089ddd1";;
        private final String ID = "########";
        String type = "/json";
        String serviceUrl = "/Grid_20150827000000000226_1";
        private String str, receiveMsg;

        @Override
        protected String doInBackground(String... params) {
            URL url = null;
            try {

                String requestnumber="/"+params[0];
                url = new URL("http://211.237.50.150:7080/openapi/"+clientKey+type+serviceUrl+requestnumber+requestnumber);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                if (conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();
                    Log.i("receiveMsg : ", receiveMsg);

                    reader.close();
                } else {
                    Log.i("통신 결과", conn.getResponseCode() + "에러");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return receiveMsg;
        }

    }

    public String apirecipe(String jsonString, String a){
        String TAG_JSON = "Grid_20150827000000000226_1";
        String TAG_JSON2 = "row";
        String TAG_ID = "RECIPE_ID";
        String TAG_NAME = "RECIPE_NM_KO";


        apisaveclass=new apisaveclass();
        try{
            JSONObject jsonObject = new JSONObject(jsonString);
            JSONObject channel = (JSONObject)jsonObject.get(TAG_JSON);
            JSONArray jsonArray = channel.getJSONArray(TAG_JSON2);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jObject = jsonArray.getJSONObject(i);

                apisaveclass.recipe_num = jObject.optString(TAG_ID);
                apisaveclass.recipe_name = jObject.optString(TAG_NAME);

                if(apisaveclass.recipe_num.equals(a)){
                    return apisaveclass.recipe_name;
                }

            }
        }catch(Exception e){
            e.printStackTrace();
        }

        return "레시피_이름정보_없음";
    }



    public class inputbuyingre extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();

            progressDialog = ProgressDialog.show(apporecipe.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "POST response  - " + result);
        }


        @Override
        protected String doInBackground(String... params) {

            String i_name = (String)params[1];
            String quantity = (String)params[2];

            String serverURL = (String)params[0];
            String postParameters = "i_name=" + i_name + "&quantity=" + quantity;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                //Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString();


            } catch (Exception e) {

                //Log.d(TAG, "InsertData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }

    public class deletebuyingre extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();

            progressDialog = ProgressDialog.show(apporecipe.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "POST response  - " + result);
        }


        @Override
        protected String doInBackground(String... params) {

            String i_name = (String)params[1];
            String category = (String)params[2];
            String recipe_num = (String)params[3];

            String serverURL = (String)params[0];
            String postParameters = "i_name=" + i_name + "&category=" + category + "&recipe_num=" + recipe_num;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                //Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString();


            } catch (Exception e) {

                Log.d(TAG, "DeleteData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }

    public class apisaveclass{
        String recipe_name;
        String recipe_num;
    }
}
