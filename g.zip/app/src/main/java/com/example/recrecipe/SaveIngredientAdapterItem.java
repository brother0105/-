package com.example.recrecipe;
// 레시피 리스트의 커스텀 리스트뷰의 layout을 위한 클래스

public class SaveIngredientAdapterItem {
    String id;
    int row;
    String name;
    String volume;
    String type;
    int type_code;

    public SaveIngredientAdapterItem(){}
    public SaveIngredientAdapterItem(String id, int row, String name, String volume, String type, int type_code){
        this.id = id;
        this.row = row;
        this.name = name;
        this.volume = volume;
        this.type = type;
        this.type_code = type_code;
    }

    public String get_id() {
        return id;
    }
    public int get_row(){
        return row;
    }
    public String get_name() {
        return name;
    }
    public String get_volume() {
        return volume;
    }
    public String get_type(){
        return type;
    }
    public int get_type_code(){
        return type_code;
    }

    public void set_id(String id) {
        this.id = id;
    }
    public void set_row(int row) {
        this.row = row;
    }
    public void set_name(String name) {
        this.name = name;
    }
    public void set_volume(String volume) {
        this.volume = volume;
    }
    public void set_type(String type){
        this.type = type;
    }
    public void set_type_code(int type_code){
        this.type_code = type_code;
    }
}



