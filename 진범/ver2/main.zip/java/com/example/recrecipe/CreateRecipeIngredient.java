package com.example.recrecipe;
import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutionException;


public class CreateRecipeIngredient extends AppCompatActivity {

    private static String IP_ADDRESS = "192.168.219.129";
    private static String TAG = "phptest";

    private EditText Ingredient_name;
    private EditText Ingredient_Volume;
    private Spinner Ingredient_spinner;

    ArrayList<SaveIngredientAdapterItem> save = new ArrayList<SaveIngredientAdapterItem>();


    private static String ingredient_type_save;

    private int ingredient_row= 0;
    private ListView ingredient_list;
    private SaveIngredientAdapter adapter_ingredient_list;

    Create_new_recipe task;


    public String id_number = "1";    // id
    public String tempname = ".jpg"; // 임시 이름



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_recipe_ingredient);

        Intent intent = getIntent();
        id_number = intent.getExtras().getString("ID");


        // edit 참조 모음
        Ingredient_name = (EditText)findViewById(R.id.edit_ingredient_name);
        Ingredient_Volume = (EditText)findViewById(R.id.edit_ingredient_volume);

        adapter_ingredient_list = new SaveIngredientAdapter();
        ingredient_list = (ListView) findViewById(R.id.ingredient_list);
        ingredient_list.setAdapter(adapter_ingredient_list);



        // name의 키보드창 다음으로 설정, summary로 가게 설정
        Ingredient_name.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        Ingredient_name.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_NEXT || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    Ingredient_name.setNextFocusDownId(R.id.edit_ingredient_volume);
                }
                return false;
            }
        });

        // time의 키보드창 다음으로 설정, difficulty로 가게 설정
        Ingredient_Volume.setImeOptions(EditorInfo.IME_ACTION_DONE);
        Ingredient_Volume.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            InputMethodManager imm_time = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_DONE || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                }
                return false;
            }
        });

        // difficulty spinner 설정

        Ingredient_spinner=(Spinner)findViewById(R.id.create_ingredient_spinner);
        Ingredient_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ingredient_type_save = parent.getItemAtPosition(position).toString();

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                ingredient_type_save = "값이 설정되어있지 않음";
            }
        });




    }

    // new recipe 생성
    public void bnt_new_ingredient(View view)
    {
        save = adapter_ingredient_list.GetArraylist();

        Create_new_recipe task = new Create_new_recipe();
        Create_new_recipe task2 = new Create_new_recipe();
        for(int i = 0; i < save.size(); i++) {

            String a = Integer.toString(save.get(i).get_row());
            String b = Integer.toString(save.get(i).get_type_code());

            task = new Create_new_recipe();
            task.execute("http://" + IP_ADDRESS + "/insert_new_ingredient.php", save.get(i).get_id(),save.get(i).get_name(),
                    a,save.get(i).get_type(),b,save.get(i).get_volume());
       }

    }

    // data base로 전송
    class Create_new_recipe extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(CreateRecipeIngredient.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "POST response  - " + result);

        }

        @Override
        protected String doInBackground(String... params) {

            String id = (String)params[1];
            String name = (String)params[2];
            String ingredient_order = (String)params[3];
            String type = (String)params[4];
            String type_code = (String)params[5];
            String volume = (String)params[6];


            String serverURL = (String)params[0];
            String postParameters = "id=" + id + "&name=" + name + "&order=" + ingredient_order + "&type=" + type + "&type_code=" + type_code + "&volume=" + volume;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString();


            } catch (Exception e) {

                Log.d(TAG, "UpdateData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }



    public void savelist(View view)
    {
        EditText name = (EditText)findViewById(R.id.edit_ingredient_name);
        EditText volume = (EditText)findViewById(R.id.edit_ingredient_volume);

        String tmp_name = name.getText().toString();
        String tmp_volume = volume.getText().toString();
        String tmp_type = ingredient_type_save;

        int ty_code = 1;
        if(tmp_type.equals("주재료")){
            ty_code =3060001;
        }
        else{
            if(tmp_type.equals("부재료")){
                ty_code = 3060002;
            }
            else{
                ty_code = 3060003;
            }
        }

        adapter_ingredient_list.addItem(id_number,tmp_name,ingredient_row,tmp_type,ty_code,tmp_volume);
        adapter_ingredient_list.notifyDataSetChanged();
        ingredient_row++;

    }

    public void next_description(View v) {
        Intent intent = new Intent(this, CreateRecipeDescription.class);
        intent.putExtra("ID",id_number);
        startActivity(intent);
    }
}
