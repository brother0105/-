package com.example.recrecipe;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


public class Newpage extends AppCompatActivity {

    private Button bg;
    private static Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpage);

        bg = (Button) findViewById(R.id.retrn);
        TestR a = (TestR)TestR.activity_testr;

        mContext = this;

        bg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                a.finish();
                Intent intent = new Intent(Newpage.this, TestR.class);
                startActivity(intent);
                finish();




            }
        });


    }


}