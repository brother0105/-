<?php 

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('dbcon.php');


    $android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");


   

       
            try{
                // SQL문을 실행하여 데이터를 MySQL 서버의 person 테이블에 저장합니다. 

                $stmt = $con->prepare("ALTER TABLE person AUTO_INCREMENT=1");
                $stmt = $con->prepare("SET @COUNT = 0");
                $stmt = $con->prepare("UPDATE person SET id = @COUNT:=@COUNT+1");


                if($stmt->execute())
                {
                    $successMSG = "정리 완료";
                }
                else
                {
                    $errMSG = "사용자 제거 에러";
                }


            } catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
            }


?>


<?php 
    if (isset($errMSG)) echo $errMSG;
    if (isset($successMSG)) echo $successMSG;

	$android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");
   
    if( !$android )
    {
?>
    <html>
       <body>

            <form action="<?php $_PHP_SELF ?>" method="POST">
                Condition: <input type = "text" name = "condition" />
                <input type = "submit" name = "submit" />
            </form>
       
       </body>
    </html>

<?php 
    }
?>