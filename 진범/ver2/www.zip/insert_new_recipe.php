<?php 

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('copydbcon.php');


    $android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");


    if( (($_SERVER['REQUEST_METHOD'] == 'POST') && isset($_POST['submit'])) || $android )
    {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 가지고 값을 전달 받습니다.

        $name=$_POST['name'];
        $summary=$_POST['summary'];
        $type=$_POST['type'];
        $time=$_POST['time'];
        $difficulty=$_POST['difficulty'];
        $cooking_url=$_POST['cooking_url'];




       
            try{
                // SQL문을 실행하여 데이터를 MySQL 서버의 person 테이블에 저장합니다. 
                $stmt = $con->prepare('INSERT INTO userrecipe(name, summary, type, time, difficulty, cooking_url) VALUES(:name, :summary, :type, :time, :difficulty, :cooking_url)');
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':summary', $summary);
                $stmt->bindParam(':type', $type);
                $stmt->bindParam(':time', $time);
                $stmt->bindParam(':difficulty', $difficulty);
                $stmt->bindParam(':cooking_url', $cooking_url);

                if($stmt->execute())
                {
                    $successMSG = "새로운 사용자를 추가했습니다.";
                }
                else
                {
                    $errMSG = "사용자 추가 에러";
                }

            } catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
            }
        

    }

?>


<?php 
    if (isset($errMSG)) echo $errMSG;
    if (isset($successMSG)) echo $successMSG;

	$android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");
   
    if( !$android )
    {
?>
    <html>
       <body>

            <form action="<?php $_PHP_SELF ?>" method="POST">
                Name: <input type = "text" name = "name" />
                Country: <input type = "text" name = "country" />
                <input type = "submit" name = "submit" />
            </form>
       
       </body>
    </html>

<?php 
    }
?>