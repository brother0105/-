package com.example.recrecipe;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class tobuyHeadVH extends apporecipeitem {
    public TextView header_title;
    public ImageView icon;
    public ArrayList<tobuyChildVH> childlist;
    int viewType=1;
    boolean invisible=true;

    public tobuyHeadVH(View itemView) {
        super(itemView);
        header_title = (TextView) itemView.findViewById(R.id.appo_list_head);
        icon = (ImageView) itemView.findViewById(R.id.appo_list_head_image);
        childlist=new ArrayList<>();
    }

    public void onBind(appo_recipe_adapter.itemlist data){
        header_title.setText(data.maincontext);

    }

    public void addchild(tobuyChildVH input){
        input.visibility(false);//전부 투명화
        childlist.add(input);

    }

    public void visibility(){
        if(invisible){
            for(int i=0;i<childlist.size();i++)
                childlist.get(i).visibility(true);
            invisible=false;
            icon.setImageResource(R.drawable.menu_icon);
        }
        else{
            for(int i=0;i<childlist.size();i++)
                childlist.get(i).visibility(false);
            invisible=true;
            icon.setImageResource(R.drawable.downarrow);
        }

    }

}
