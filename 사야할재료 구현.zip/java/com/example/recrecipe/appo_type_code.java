package com.example.recrecipe;

public class appo_type_code {
    public class ViewType{
        public static final int HEAD = 1;
        public static final int CHILD = 2;
    }
}
