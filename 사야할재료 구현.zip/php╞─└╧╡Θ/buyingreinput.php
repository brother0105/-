<?php 

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('dbcon.php');


    $android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");


    if( (($_SERVER['REQUEST_METHOD'] == 'POST') && isset($_POST['submit'])) || $android )
    {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 가지고 값을 전달 받습니다.

        $i_name=$_POST['i_name'];
        $quantity=$_POST['quantity'];

        if(empty($i_name)){
            $errMSG = "레시피 번호가 들어오지 않았습니다.";
        }

        if(!isset($errMSG)) // 모두 입력이 되었다면 
        {
            try{
                // SQL문을 실행하여 데이터를 MySQL 서버의 tobuyingre 테이블에 저장합니다. 
                $stmt = $con->prepare('insert into tobuyingre values (0,"개인입력",:i_name,:quantity)');
                $stmt->bindParam(':i_name', $i_name);
                $stmt->bindParam(':quantity', $quantity);

                if($stmt->execute())
                {
                    $successMSG = "사야할 재료를 추가했습니다.";
                }
                else
                {
                    $errMSG = "사야할 재료 추가 에러";
                }

            } catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
            }
        }

    }

?>