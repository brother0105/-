package com.example.test;

public class ListViewItem {
    private String idStr;
    private String ingreStr ;
    private String numStr ;
    private String dateStr ;

    public String getIdStr() { return idStr; }

    public void setIdStr(String idStr) { this.idStr = idStr; }

    public String getIngreStr() {
        return ingreStr;
    }

    public void setIngreStr(String ingreStr) {
        this.ingreStr = ingreStr;
    }

    public String getNumStr() {
        return numStr;
    }

    public void setNumStr(String numStr) {
        this.numStr = numStr;
    }

    public String getDateStr() {
        return dateStr;
    }

    public void setDateStr(String dateStr) {
        this.dateStr = dateStr;
    }
}