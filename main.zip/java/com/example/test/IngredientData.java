package com.example.test;

public class IngredientData {

    private String ingreId;
    private String ingreName;
    private String ingreNum;
    private String ingreDate;

    public String getIngreId() { return ingreId; }

    public void setIngreId(String ingreId) { this.ingreId = ingreId; }

    public String getIngreName() {
        return ingreName;
    }

    public void setIngreName(String ingreName) {
        this.ingreName = ingreName;
    }

    public String getIngreNum() {
        return ingreNum;
    }

    public void setIngreNum(String ingreNum) {
        this.ingreNum = ingreNum;
    }

    public String getIngreDate() {
        return ingreDate;
    }

    public void setIngreDate(String ingreDate) {
        this.ingreDate = ingreDate;
    }
}
