-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- 생성 시간: 21-10-10 06:43
-- 서버 버전: 5.7.31
-- PHP 버전: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `testrecipe`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `testingredient`
--

DROP TABLE IF EXISTS `testingredient`;
CREATE TABLE IF NOT EXISTS `testingredient` (
  `id` varchar(255) NOT NULL,
  `ing_order` bigint(20) NOT NULL,
  `ing_name` varchar(255) NOT NULL,
  `ing_volume` varchar(255) NOT NULL,
  `type_code` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `testingredient`
--

INSERT INTO `testingredient` (`id`, `ing_order`, `ing_name`, `ing_volume`, `type_code`, `type`) VALUES
('1', 1, 'ㄹㄴㅇㄹ1', 'ㄹㅇㄴㄹ1', 3060001, '주재료'),
('1', 0, '1', '1', 3060001, '주재료'),
('1', 1, '1', '1', 3060001, '주재료'),
('1', 2, '1', '1', 3060001, '주재료'),
('1', 0, '1', '233', 3060001, '주재료'),
('1', 1, '1', '233', 3060001, '주재료'),
('1', 2, '1', '233', 3060001, '주재료'),
('195455', 0, '1', '1', 3060001, '주재료'),
('195455', 1, '12', '12', 3060001, '주재료'),
('195455', 0, '감자', '1개', 3060001, '주재료'),
('195455', 8, '당근', '1개', 3060002, '부재료'),
('195455', 9, '당근', '1개', 3060003, '양념'),
('195455', 31, '당근', '1개', 3060001, '주재료'),
('195455', 0, '감자', '1개', 3060001, '주재료'),
('195455', 8, '당근', '1개', 3060002, '부재료'),
('195455', 9, '당근', '1개', 3060003, '양념'),
('195455', 31, '당근', '1개', 3060001, '주재료'),
('195455', 0, 'ㄹㄴㅇㄹㄴㅇ', 'ㄹㅇㄴㄹㅇㄴ', 3060001, '주재료'),
('195455', 1, 'ㄹㄴㅇㄹㄴㅇ', 'ㄹㅇㄴㄹㅇㄴ', 3060001, '주재료'),
('195455', 2, 'ㄹㄴㅇㄹㄴㅇ', 'ㄹㅇㄴㄹㅇㄴ', 3060001, '주재료'),
('195455', 0, '딸기', '2개', 3060001, '주재료'),
('195455', 1, '생크림', '500ml', 3060001, '주재료'),
('195455', 2, '사과', '2개', 3060002, '부재료');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
