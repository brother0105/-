-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- 생성 시간: 21-10-10 06:42
-- 서버 버전: 5.7.31
-- PHP 버전: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `testrecipe`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `userrecipe`
--

DROP TABLE IF EXISTS `userrecipe`;
CREATE TABLE IF NOT EXISTS `userrecipe` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `difficulty` varchar(255) NOT NULL,
  `cooking_url` varchar(255) NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `userrecipe`
--

INSERT INTO `userrecipe` (`id`, `name`, `summary`, `type`, `time`, `difficulty`, `cooking_url`) VALUES
('195455', '123', '123', '123', '123', '초보환영', '195455.jpg'),
('test213', 'ㅇㄴㄹ', 'ㄴㅇㄹ', 'ㄷㄹㅈ', 'ㄹㄷㅈ', '초보환영', '195455.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
