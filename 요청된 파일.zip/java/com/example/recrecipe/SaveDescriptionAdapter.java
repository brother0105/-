package com.example.recrecipe;
//레시피 리스트의 커스텀 리스트뷰를 위한 클래스

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Environment;
import androidx.core.content.ContextCompat;
import androidx.core.content.ContextCompat;


import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

public class SaveDescriptionAdapter extends BaseAdapter {


    public CreateRecipeDescription a;
    public String sa;

    // Adapter에 추가된 데이터를 저장하기 위한 ArrayList
    private ArrayList<SaveDescriptionAdapterItem> listViewItemList = new ArrayList<SaveDescriptionAdapterItem>() ;

    // ListViewAdapter의 생성자
    public SaveDescriptionAdapter() {

        sa = "내용없음";

    }

    // Adapter에 사용되는 데이터의 개수를 리턴. : 필수 구현
    @Override
    public int getCount() {
        return listViewItemList.size() ;
    }

    // position에 위치한 데이터를 화면에 출력하는데 사용될 View를 리턴. : 필수 구현
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();


        // "listview_item" Layout을 inflate하여 convertView 참조 획득.
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.savedescriptionadapter_item, parent, false);
        }

        // 화면에 표시될 View(Layout이 inflate된)으로부터 위젯에 대한 참조 획득
        ImageView des_image = (ImageView) convertView.findViewById(R.id.description_image);
        TextView titleTextView = (TextView) convertView.findViewById(R.id.description_text1);

        Button bnt_delete = (Button) convertView.findViewById(R.id.save_description_list_button);

        // Data Set(listViewItemList)에서 position에 위치한 데이터 참조 획득
        SaveDescriptionAdapterItem listViewItem = listViewItemList.get(position);

        // 아이템 내 각 위젯에 데이터 반영
        titleTextView.setText(listViewItem.get_description());



        bnt_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewItemList.remove(position);
                notifyDataSetChanged();
            }
        });
        /////////////////////////이미지뷰 로드////////////////////////////////
        //sa = a.toadapter();
        a = new CreateRecipeDescription();
        sa = ((CreateRecipeDescription)CreateRecipeDescription.context_main).toadapter();


        try {

            File storageDir = new File(sa);
            String filename = listViewItem.get_pic();

            File file = new File(storageDir, filename);
            Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
            des_image.setImageBitmap(bitmap);

        } catch (Exception e) {
            Log.w("CameraActivity", "Capture loading Error!", e);
        }


        ///////////////////////////////////////////////////////

        return convertView;
    }


    // 지정한 위치(position)에 있는 데이터와 관계된 아이템(row)의 ID를 리턴. : 필수 구현
    @Override
    public long getItemId(int position) {
        return position ;
    }

    // 지정한 위치(position)에 있는 데이터 리턴 : 필수 구현
    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position) ;
    }

    // 아이템 데이터 추가를 위한 함수. 개발자가 원하는대로 작성 가능.
    public void addItem(String id, int row, String description, String pic_name) {
        SaveDescriptionAdapterItem item = new SaveDescriptionAdapterItem();

        item.set_id(id);
        item.set_row(row);
        item.set_description(description);
        item.set_pic_name(pic_name);

        listViewItemList.add(item);
    }
    public ArrayList<SaveDescriptionAdapterItem> GetArraylist(){
        return listViewItemList;
    }

}